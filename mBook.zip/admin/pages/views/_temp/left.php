<div class="box one-field">
	<div class="box-header with-border">Menu header</div>
	<div class="box-body">
		<a class="one-menu">Menu 1</a>
		<a class="one-menu">Menu 1</a>
		<a class="one-menu">Menu 1</a>
		<a class="one-menu">Menu 1</a>
	</div>
</div>
<div class="box one-field">
	<div class="box-header with-border">Menu header</div>
	<div class="box-body">
		<a class="one-menu">Menu 2</a>
		<a class="one-menu">Menu 2</a>
		<a class="one-menu">Menu 2</a>
		<a class="one-menu">Menu 2</a>
	</div>
</div>
