</div> <!-- #main -->
</div> <!-- #main-content -->
	
<div class="popup hide"><div class="popup-inner">
	<div class="popup-content hide">
		<a class="popup-btn" role="close"></a>
		<div class="the-board"></div>
	</div>
</div></div>
	<?php $config->echoJS() ?>

</body>
</html>
