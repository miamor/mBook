zzChat
===
###Chatbox forumvi
Tạo trang HTML mới, và sử dụng mã nguồn trong trang dưới đây:

    view-source:http://baivong.github.io/cdn/zzchat/0.2/zzchat.html
