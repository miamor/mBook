<?php
$page_title = 'Welcome to mBook!';
if (!$do && !$v && !$temp) include 'pages/views/_temp/header.php';
?>
Xin chào!
