<?php
echo $noti->setRead();
