<?php
$box->lock();
echo $box->stt;
