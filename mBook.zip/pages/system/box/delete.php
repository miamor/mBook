<?php
$box->delete();
