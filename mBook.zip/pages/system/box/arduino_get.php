<?php
$lastInProgress = $box->lastInProgress();
echo $lastInProgress['square_id'];

/*$ar = array('id' => 1, 'square_id' => 2);
echo json_encode($ar);
*/
