<?php
$status = $config->get('stt');
//if ($status == 1) 
	$box->arduinoBuy_finishGet();
echo $status;
