<?php
echo ($box->handleBuy()) ? 1 : 0;
