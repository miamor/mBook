<?php
echo ($post->like()) ? 1 : 0;
