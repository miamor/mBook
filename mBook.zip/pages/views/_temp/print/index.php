<div class="p-index">
	<h1>Tìm kiếm bản in</h1>
	<input type="text" class="form-control" name="barcode" placeholder="Input book barcode"/>
	<div>Or scan your barcode</div>
	<input type="file" name="barcode_img"/>
	<div>Or scan book cover</div>
	<input type="file" name="cover_img"/>
</div>

