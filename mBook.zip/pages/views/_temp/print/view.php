<?php print_r($_View); ?>
<h2><?php echo $title ?></h2>
<div class="barcode">
	<?php echo $print->barcode ?>
</div>