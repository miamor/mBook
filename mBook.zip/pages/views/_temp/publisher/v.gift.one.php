<h3>Chia sẻ để nhận</h3>

<div class="publisher-gifts">

<div class="feed-one-item feed-item-gift">
	<div class="feed-user-info col-lg-1 no-padding centered">
		<a href="#" data-online="1">
			<img class="feed-user-avt img-circle" src="http://localhost/mRoom/data/img/7.jpg"/>
		</a>
	</div>
	<div class="feed-content col-lg-11 no-padding feed-gift">
		<div class="box box-gift feed-main col-lg-8 feed-gift-main">
			<div class="box-header feed-main-head feed-gift-head">
				<a href="#">NXB 1</a> sẽ tặng <strong class="text-success">1</strong> cuốn sách cho người chia sẻ bài viết <a class="text-info" href="#" title="What's this?"><i class="fa fa-info-circle"></i></a>
			</div>
			<div class="box-body feed-main-content feed-gift-content">
A book review is a descriptive and critical/evaluative account of a book. It provides a summary of the content, assesses the value of the book, and recommends it (or not) to other potential readers.<br/>
A book report is an objective summary of the main ideas and arguments that the book's author has presented. The purpose of the report is to give enough information to help decide whether the book will be of use or interest to any potential readers.<br/>
A book report is an objective summary of the main ideas and arguments that the book's author has presented. The purpose of the report is to give enough information to help decide whether the book will be of use or interest to any potential readers.<br/>
A book report is an objective summary of the main ideas and arguments that the book's author has presented. The purpose of the report is to give enough information to help decide whether the book will be of use or interest to any potential readers.<br/>
Common points that both book reviews and book reports share are presented below. The last point, Critical Comments, is intended only for those writing book reviews.
			</div>

			<div class="box-footer stat feed-sta">
				<div class="feed-cmts text-danger stat-one col-lg-6 no-padding">
					<strong>28</strong>
					comments
				</div>
				<div class="feed-share text-info stat-one col-lg-6 no-padding text-right">
					<a href="#share">
						<strong>8</strong>
						share
					</a>
				</div>
			</div>
			
			<div class="box-footer box-comments">
				<div class="box-comment">
					<a href="#" class="comment-text">
						<i class="fa fa-refresh"></i> Tải thêm bình luận
					</a><!-- /.comment-text -->
				</div><!-- /.box-comment -->
				<div class="box-comment">
					<div class="box-comment-left">
						<a href="#" data-online="0">
							<img class="img-circle img-sm" src="<? echo IMG ?>/user3-128x128.jpg" alt="user image"/>
						</a>
					</div>
					<div class="comment-text">
						<span class="username">
							<a href="#">Maria Gonzales</a>
							<span class="text-muted pull-right">8:03 PM Today</span>
						</span><!-- /.username -->
						It is a long established fact that a reader will be distracted
						by the readable content of a page when looking at its layout... <a class="gensmall" href="#">See more</a>
					</div><!-- /.comment-text -->
				</div><!-- /.box-comment -->
				<div class="box-comment">
					<div class="box-comment-left">
						<a href="#" data-online="0">
							<img class="img-circle img-sm" src="<? echo IMG ?>/user4-128x128.jpg" alt="user image"/>
						</a>
					</div>
					<div class="comment-text">
						<span class="username">
							<a href="#">Luna Stark</a>
							<span class="text-muted pull-right">8:03 PM Today</span>
						</span><!-- /.username -->
						It is a long established fact that a reader will be distracted
						by the readable content of a page when looking at its layout... <a class="gensmall" href="#">See more</a>
					</div><!-- /.comment-text -->
				</div><!-- /.box-comment -->
			</div><!-- /.box-footer -->

		</div>
		<div class="col-lg-4 no-padding-right feed-gift-book">
			<div class="books">
				<div class="books-one-thumb col-lg-4 active">
					<img class="book-thumb" src="http://localhost/mBook/data/img/b2.png"/>
				</div>
				<div class="books-one-thumb col-lg-4">
					<img class="book-thumb" src="http://localhost/mBook/data/img/b1.png"/>
				</div>
				<div class="books-one-thumb col-lg-4">
					<img class="book-thumb" src="http://localhost/mBook/data/img/b3.png"/>
				</div>
				<div class="clearfix"></div>
			</div>
			
			<div class="book-one" id="2">
				<div class="book-rate">
					<div class="book-score left text-warning">
						4.5
					</div>
					<div class="book-ratings-details">
						<div class="ratings book-ratings text-warning">
							<i class="fa fa-star"></i>
							<i class="fa fa-star"></i>
							<i class="fa fa-star"></i>
							<i class="fa fa-star-half-o"></i>
							<i class="fa fa-star-o"></i>
						</div>
						<a href="#" title="View all 15 reviews" class="gensmall">(15 reviews)</a>
					</div>
				</div>
				<div class="book-details no-padding">
					<div class="">
						<div class="book-genres">
							<b>Thể loại:</b> <a href="#">Lãng mạn</a>, <a href="#">Hiện thực</a>, <a href="#">Đời thường</a>
						</div>
						<div class="book-genres">
							<b>Tác giả:</b> <a href="#">Auth name</a>
						</div>
					</div>
				</div>
			</div>
			
			<div class="time-left">
				<span class="countdown">06:20:24</span>
			</div>
		</div>
			
		<div class="clearfix"></div>
	</div>
	
	<div class="clearfix"></div>
</div>


</div>

<div class="clearfix">
</div>