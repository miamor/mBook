<div class="col-lg-1"></div>

<div class="event-info col-lg-10">

<div class="feed-one-item feed-item-event">
	<div class="feed-user-info col-lg-1 no-padding centered">
		<a href="#" data-online="1">
			<img class="feed-user-avt img-circle" src="http://localhost/mRoom/data/img/17.jpg"/>
		</a>
	</div>
	<div class="feed-content col-lg-11 no-padding feed-ev">
		<div class="box box-event feed-main col-lg-8 feed-ev-main">
			<div class="box-header feed-main-head feed-ev-head">
				<a href="#">NXB 1</a> đã thêm 1 <a href="#">sự kiện</a> ngày <b>26/03/2016</b>
			</div>
			<div class="box-body feed-main-content feed-ev-content">
A book review is a descriptive and critical/evaluative account of a book. It provides a summary of the content, assesses the value of the book, and recommends it (or not) to other potential readers.<br/>
A book report is an objective summary of the main ideas and arguments that the book's author has presented. The purpose of the report is to give enough information to help decide whether the book will be of use or interest to any potential readers.<br/>
A book report is an objective summary of the main ideas and arguments that the book's author has presented. The purpose of the report is to give enough information to help decide whether the book will be of use or interest to any potential readers.<br/>
A book report is an objective summary of the main ideas and arguments that the book's author has presented. The purpose of the report is to give enough information to help decide whether the book will be of use or interest to any potential readers.<br/>
Common points that both book reviews and book reports share are presented below. The last point, Critical Comments, is intended only for those writing book reviews.
			</div>

			<div class="box-footer stat feed-sta">
				<div class="feed-follow text-success stat-one col-lg-6 no-padding">
					<strong>142</strong>
					Follow
				</div>
				<div class="feed-share text-info stat-one col-lg-6 no-padding text-right">
					<a href="#share">
						<strong>228</strong>
						share
					</a>
				</div>
			</div>
			
			<div class="box-footer box-comments">
				<div class="box-comment">
					<div class="box-comment-left">
						<a href="#" data-online="0">
							<img class="img-circle img-sm" src="<? echo IMG ?>/user3-128x128.jpg" alt="user image"/>
						</a>
					</div>
					<div class="comment-text">
						<span class="username">
							<a href="#">Maria Gonzales</a>
							<span class="text-muted pull-right">8:03 PM Today</span>
						</span><!-- /.username -->
						It is a long established fact that a reader will be distracted
						by the readable content of a page when looking at its layout... <a class="gensmall" href="#">See more</a>
					</div><!-- /.comment-text -->
				</div><!-- /.box-comment -->
				<div class="box-comment">
					<div class="box-comment-left">
						<a href="#" data-online="0">
							<img class="img-circle img-sm" src="<? echo IMG ?>/user4-128x128.jpg" alt="user image"/>
						</a>
					</div>
					<div class="comment-text">
						<span class="username">
							<a href="#">Luna Stark</a>
							<span class="text-muted pull-right">8:03 PM Today</span>
						</span><!-- /.username -->
						It is a long established fact that a reader will be distracted
						by the readable content of a page when looking at its layout... <a class="gensmall" href="#">See more</a>
					</div><!-- /.comment-text -->
				</div><!-- /.box-comment -->
			</div><!-- /.box-footer -->

		</div>
		<div class="col-lg-4 no-padding-right feed-ev-details">
			<div class="event-place">
				<b>Thời gian:</b> 22 - 29/03/2017
			</div>
			<div class="event-place">
				<b>Địa điểm:</b> Công viên Thống Nhất
			</div>
			<div class="event-map">
			</div>
			<div class="event-buttons">
				<a href="#" class="btn btn-block btn-social btn-facebook">
					<i class="fa fa-facebook"></i> Facebook link
				</a>
			</div>
		</div>
			
		<div class="clearfix"></div>
	</div>
	
	<div class="clearfix"></div>
</div>


</div>

<div class="col-lg-1"></div>

<div class="clearfix"></div>
