<div class="feed-one-item feed-item-review">
	<div class="feed-user-info col-lg-1 no-padding centered">
		<a href="#" data-online="1">
			<img class="feed-user-avt img-circle" src="http://localhost/mRoom/data/img/7.jpg"/>
		</a>
	</div>
	<div class="feed-content col-lg-11 no-padding feed-rq">
		<div class="box box-request feed-main col-lg-12 feed-rq-main">
			<div class="box-header feed-main-head feed-rq-head">
				<a href="#">Tu Nguyen</a> đề nghị <b>dịch</b> cuốn sách <a href="#">Responsive Web design</a>
			</div>
			<div class="box-body">
		<div class="col-lg-2 no-padding feed-rq-book">
			<img class="book-thumb" src="http://localhost/mBook/data/img/b1.png"/>
		</div>
		<div class="col-lg-10 no-padding-right feed-rq-book">
			<div class="book-rate no-margin-top">
				<div class="book-score left text-warning">
					4.5
				</div>
				<div class="book-ratings-details">
					<div class="ratings book-ratings text-warning">
						<i class="fa fa-star"></i>
						<i class="fa fa-star"></i>
						<i class="fa fa-star"></i>
						<i class="fa fa-star-half-o"></i>
						<i class="fa fa-star-o"></i>
					</div>
					<a href="#" title="View all 15 reviews" class="gensmall">(15 reviews)</a>
				</div>
			</div>
			<div class="book-des no-padding">
A book review is a descriptive and critical/evaluative account of a book. It provides a summary of the content, assesses the value of the book, and recommends it (or not) to other potential readers.<br/>
A book report is an objective summary of the main ideas and arguments that the book's author has presented. The purpose of the report is to give enough information to help decide whether the book will be of use or interest to any potential readers.<br/>
			</div>
			<div class="book-details no-padding">
				<div class="book-genres">
					<b>Thể loại:</b> <a href="#">Lãng mạn</a>, <a href="#">Hiện thực</a>, <a href="#">Đời thường</a>
				</div>
				<div class="book-genres">
					<b>Tác giả:</b> <a href="#">Auth name</a>
				</div>
			</div>
		</div>
				<div class="clearfix"></div>
			</div>
			<div class="box-footer stat feed-sta">
				<div class="feed-re-request stat-one col-lg-4 no-padding">
					<a class="btn btn-success" href="#request">
						<i class="fa fa-retweet"></i> Re-request
					</a>
				</div>
				<div class="text-primary stat-one col-lg-4 no-padding text-center">
					<strong>45</strong>
					requests
				</div>
				<div class="feed-share text-info stat-one col-lg-4 no-padding text-right">
					<a href="#share">
						<strong>8</strong>
						share
					</a>
				</div>
			</div>
			
		</div>
			
		<div class="clearfix"></div>
	</div>
	
	<div class="clearfix"></div>
</div>

